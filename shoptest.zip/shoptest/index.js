var httpurl = 'http://localhost:8093/'

var productClassAttributeRequiredData = ["是", "否"];
var productClassAttributeTypeData = ["输入框", "时间", "选择框"];


function ajaxPost(url, data, callback) {
	$.ajax({
		type: 'post',
		url: httpurl + url,
		data: JSON.stringify(data),
		dataType: "json",
		contentType: 'application/json',
		xhrFields: {
			withCredentials: true
		},
		success: function(result) {
			if (result.code == 200) {
				callback(result.data);
			} else {
				alert(result.msg)
			}
		},
		error: function(err) {
			console.log(err)
		}
	});
}

function ajaxGet(url, data, callback) {
	$.ajax({
		type: 'GET',
		url: httpurl + url,
		data: data,
		success: function(result) {
			if (result.code == 200) {
				callback(result.data);
			} else {
				alert(result.msg)
			}
		},
		error: function(err) {
			console.log(err)
		}
	});
}

function uploadFn(id, resultId, multiple) {
	if(multiple) {
		multiple = true
	}
	$("#" + id).change(function() {
		var files = $(this)[0].files;
		var formData = new FormData();
		if (files.length > 0) {
			for (var i = 0; i < files.length; i++) {
				formData.append('file', files[i]);
				$.ajax({
					type: 'post',
					url: httpurl + "upload",
					data: formData,
					processData: false,
					contentType: false,
					success: function(result) {
						if (result.code == 200) {
							if (multiple) {
								var url = $("#" + resultId).val();
								if (!url) {
									$("#" + resultId).val(result.data)
								} else {
									$("#" + resultId).val(url + "," + result.data)
								}
							} else {
								$("#" + resultId).val(result.data)
							}
						} else {
							alert(result.msg)
						}
					},
					error: function(err) {
						console.log(err)
					}
				});
			}
		}
	});
}

function ajaxHtml(url) {
	$.ajax({
		url: url,
		dataType: 'html',
		type: 'get',
		beforeSend: function(data) {
			$("#iframe").empty();
		},
		success: function(data) {
			$("#iframe").html(data);
		},
		error: function(e) {
			console.log(e)
		}
	});
}

var page_index = window.sessionStorage.getItem("page_index");
var page_url = window.sessionStorage.getItem("page_url");
if (page_index) {
	ajaxHtml(`./page/${page_url}.html`);
	$("#left li").removeClass("active");
	$("#left li:eq(" + page_index + ")").addClass("active");
} else {
	ajaxHtml("./page/productCategory.html")
}

$("#left li").click(function() {
	$("#left li").removeClass("active");
	$(this).addClass("active");
	var index = $(this).index();
	var lang = $(this).attr("lang");
	window.sessionStorage.setItem("page_index", index);
	window.sessionStorage.setItem("page_url", lang);
	ajaxHtml(`./page/${lang}.html`);
})
