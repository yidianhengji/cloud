﻿function setSize() {
    var width = $("#iframe").width();
    var height = $("#iframe").height();
    var rightWidth = $("#rightContent").width( width - 275 );
    var contentHeight = height - 2;
    var treeContentHeight = height - 33;
    $("#rightContent").css({ "height": (contentHeight - 1) + "px" });
    $("#leftContent").css({ "height": contentHeight + "px" });
    $("#leftContent .treeContent").css({ "height": treeContentHeight + "px" });
    $(".leftContent").css({ "height": (contentHeight - 31) + "px" });
    $("#treeContent").css({ "height": (contentHeight - 31 - 31) + "px" });
    $(".rightContent").css({ "height": (contentHeight - 31) + "px" });
}

$(window).resize(function () {
    setSize();
    setSize1();
});

function arrowClick() {
    $("#leftContent .title #ariaHidden").click(function () {
        if (!$("#leftContent").is(":animated")) {
            if ($("#leftContent").width() == "260") {
                $("#leftContent").animate({ "width": "20px" }, 500);
                setTimeout(function () {
                    $("#leftContent .title label").hide();
                    $(".treeContent").hide();
                    $("#leftContent .title #ariaHidden").removeClass("fa-angle-double-left").addClass("fa-angle-double-right");
                }, 300);

                $("#rightContent").animate({ "width": "+=240px" }, 500);
                $(".rightContent").animate({ "width": "+=240px" }, 500);
            }
            else {
                $("#leftContent").animate({ "width": "260px" }, 500);
                setTimeout(function () {
                    $("#leftContent .title label").show();
                    $(".treeContent").show();
                    $("#leftContent .title #ariaHidden").removeClass("fa-angle-double-right").addClass("fa-angle-double-left");
                }, 200);

                $("#rightContent").animate({ "width": "-=240px" }, 500);
                $(".rightContent").animate({ "width": "-=240px" }, 500);
            }
        }
    });

    $(".leftContent .title #ariaHidden").click(function () {
        if (!$(".leftContent").is(":animated")) {
            if ($(".leftContent").width() == "260") {
                $(".leftContent").animate({ "width": "20px" }, 500);
                setTimeout(function () {
                    $(".leftContent .title label").hide();
                    $("#treeContent").hide();
                    $(".leftContent .title #ariaHidden").removeClass("fa-angle-double-left").addClass("fa-angle-double-right");
                }, 300);

                $(".rightContent").animate({ "width": "+=240px" }, 500);
            }
            else {
                $(".leftContent").animate({ "width": "260px" }, 500);
                setTimeout(function () {
                    $(".leftContent .title label").show();
                    $("#treeContent").show();
                    $(".leftContent .title #ariaHidden").removeClass("fa-angle-double-right").addClass("fa-angle-double-left");
                }, 200);

                $(".rightContent").animate({ "width": "-=240px" }, 500);
            }
        }
    });
}



setSize1();
function setSize1() {
    var width = $(window).width();
    var height = $(window).height();
    var rightWidth = $("#rightContent1").width(width - 275);
    var contentHeight = height - 2;
    var treeContentHeight = height - 33;
    $("#rightContent1").css({ "height": (contentHeight - 1) + "px" });
    $("#leftContent1").css({ "height": contentHeight + "px" });
    $("#leftContent1 .treeContent").css({ "height": treeContentHeight + "px" });
    $(".treeContent1").css({ "height": (contentHeight - 46) + "px" });
    $("#treeContent1").css({ "height": (contentHeight - 46 - 31) + "px" });
    $(".rightContent").css({ "height": (contentHeight - 36) + "px" });
}


function arrowClick1() {
    $("#leftContent1 .title #ariaHidden1").click(function () {
        if (!$("#leftContent1").is(":animated")) {
            if ($("#leftContent1").width() == "260") {
                $("#leftContent1").animate({ "width": "20px" }, 500);
                setTimeout(function () {
                    $("#leftContent1 .title label").hide();
                    $(".treeContent1").hide();
                    $("#leftContent1 .title #ariaHidden1").removeClass("fa-angle-double-left").addClass("fa-angle-double-right");
                }, 300);

                $("#rightContent1").animate({ "width": "+=240px" }, 500);
                $(".rightContent1").animate({ "width": "+=240px" }, 500);
            }
            else {
                $("#leftContent1").animate({ "width": "260px" }, 500);
                setTimeout(function () {
                    $("#leftContent1 .title label").show();
                    $(".treeContent1").show();
                    $("#leftContent1 .title #ariaHidden1").removeClass("fa-angle-double-right").addClass("fa-angle-double-left");
                }, 200);

                $("#rightContent1").animate({ "width": "-=240px" }, 500);
                $(".rightContent1").animate({ "width": "-=240px" }, 500);
            }
        }
    });

    $(".leftContent1 .title #ariaHidden1").click(function () {
        if (!$(".leftContent1").is(":animated")) {
            if ($(".leftContent1").width() == "260") {
                $(".leftContent1").animate({ "width": "20px" }, 500);
                setTimeout(function () {
                    $(".leftContent1 .title label").hide();
                    $("#treeContent1").hide();
                    $(".leftContent1 .title #ariaHidden1").removeClass("fa-angle-double-left").addClass("fa-angle-double-right");
                }, 300);

                $(".rightContent1").animate({ "width": "+=240px" }, 500);
            }
            else {
                $(".leftContent1").animate({ "width": "260px" }, 500);
                setTimeout(function () {
                    $(".leftContent1 .title label").show();
                    $("#treeContent1").show();
                    $(".leftContent1 .title #ariaHidden1").removeClass("fa-angle-double-right").addClass("fa-angle-double-left");
                }, 200);

                $(".rightContent1").animate({ "width": "-=240px" }, 500);
            }
        }
    });
}