﻿/// <reference path="jquery.ztree.core.min.js" />
/// <reference path="jquery.ztree.excheck.min.js" />
var setting = {
    async: {
        enable: true,
        url: "zTree.ashx",
        autoParam: ["id=id"],
        type: "post"
    },
    view: {
        dblClickExpand: false
    },
    data: {
        simpleData: {
            enable: true,
            idKey: "id",
            pIdKey: "parentId",
            rootPId: 0
        }
    },
    callback: {
        beforeClick: beforeClick,
        onClick: onClick
    }
};


var zNodes;

function beforeClick(treeId, treeNode) {
    var check = (treeNode && !treeNode.isParent);
    console.log(check);
    return true;
}

function onClick(e, treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
    nodes = zTree.getSelectedNodes(),
    v = "";
    var code = "";
    nodes.sort(function compare(a, b) { return a.id - b.id; });
    for (var i = 0, l = nodes.length; i < l; i++) {
        //v += nodes[i].name + ",";  
        v = nodes[i].name;
        code = nodes[i].id;
    }
    if (v.length > 0) v = v.substring(0, v.length);//-1  

    console.log(code);
}

$(document).ready(function () {
    $.ajax({
        url: "zTree.ashx",
        type: "POST",
        dataType: "json",
        data: {
            id: 0
        },
        success: function (returnData, status) {
            if (status = "success") {
                zNodes = returnData;
                $.fn.zTree.init($("#treeDemo"), setting, zNodes);
            }
        }
    });
});